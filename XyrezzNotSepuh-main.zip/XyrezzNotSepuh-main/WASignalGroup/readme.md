# Signal-Group

This contains the code to decrypt/encrypt WA group messages. 
Originally from [pokearaujo/libsignal-node](https://github.com/pokearaujo/libsignal-node)

The code has been moved outside the signal package as I felt it didn't belong in ths signal package, as it isn't inherently a part of signal but of WA.